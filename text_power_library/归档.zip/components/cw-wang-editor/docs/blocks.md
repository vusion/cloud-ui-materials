### 基本用法

``` html
<cw-wang-editor scroll></cw-wang-editor>
```
