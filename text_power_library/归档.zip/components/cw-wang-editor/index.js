import CwWangEditor from "./index.vue"

export default CwWangEditor