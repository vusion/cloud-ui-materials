import MEmitter from './index.vue';

export {
    MEmitter,
};

export default MEmitter;
