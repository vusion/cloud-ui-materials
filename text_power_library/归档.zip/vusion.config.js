module.exports = {
    type: 'component',
    docs: {
        components: [
            { group: '组件', name: 'cw-wang-editor',path: "./components/cw-wang-editor/api.yaml"},,
            // Conponents Route List
        ],
    },
};
