### 基本用法

``` html
<cw-echart-basic-view></cw-echart-basic-view>
```
