import CwEchartBasicView from "./index.vue"

export default CwEchartBasicView