### 基本用法

``` html
<cw-echart-line-view></cw-echart-line-view>
```
