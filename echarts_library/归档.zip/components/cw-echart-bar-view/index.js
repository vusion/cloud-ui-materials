import CwEchartBarView from "./index.vue"

export default CwEchartBarView