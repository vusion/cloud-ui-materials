### 基本用法

``` html
<cw-echart-bar-view xAxisTitle="X轴标题" yAxisTitle="Y轴标题" title="标题" theme="theme1"></cw-echart-bar-view>
```
