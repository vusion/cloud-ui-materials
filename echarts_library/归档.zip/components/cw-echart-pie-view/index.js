import CwEchartPieView from "./index.vue"

export default CwEchartPieView