export const fakeData = {
  "number": 1,
  "last": true,
  "size": 20,
  "numberOfElements": 5,
  "totalPages": 1,
  "content": [
    {
      "student": {
        "id": 1186261414970368,
        "createdTime": "2022-03-25T07:47:37.000Z",
        "updatedTime": "2022-03-25T08:58:52.000Z",
        "createdBy": null,
        "updatedBy": null,
        "fakeXAxis": "数据1",
        "指标1": 90,
        "指标2": 70,
        "指标3": 80,
        "age": 18,
        "sex": "男",
        "averageScore": 80,
        "mentor": "王老师",
        "donation": 300
      }
    },
    {
      "student": {
        "id": 1186279085573120,
        "createdTime": "2022-03-25T08:57:51.000Z",
        "updatedTime": "2022-03-25T08:57:51.000Z",
        "createdBy": null,
        "updatedBy": null,
        "fakeXAxis": "数据2",
        "指标1": 60,
        "指标2": 90,
        "指标3": 80,
        "age": 25,
        "sex": "女",
        "averageScore": 80,
        "mentor": "王老师",
        "donation": 1400
      }
    },
    {
      "student": {
        "id": 1186271644877824,
        "createdTime": "2022-03-25T08:28:16.000Z",
        "updatedTime": "2022-03-25T08:59:05.000Z",
        "createdBy": null,
        "updatedBy": null,
        "fakeXAxis": "数据3",
        "指标1": 75,
        "指标2": 100,
        "指标3": 85,
        "age": 20,
        "sex": "女",
        "averageScore": 95,
        "mentor": "张老师",
        "donation": 1000
      }
    },
    {
      "student": {
        "id": 1186279312065536,
        "createdTime": "2022-03-25T08:58:45.000Z",
        "updatedTime": "2022-03-25T08:58:45.000Z",
        "createdBy": null,
        "updatedBy": null,
        "fakeXAxis": "数据4",
        "指标1": 88,
        "指标2": 65,
        "指标3": 82,
        "age": 22,
        "sex": "男",
        "averageScore": 75,
        "mentor": "张老师",
        "donation": 2700
      }
    },{
      "student": {
        "id": 1186279312065536,
        "createdTime": "2022-03-25T08:58:45.000Z",
        "updatedTime": "2022-03-25T08:58:45.000Z",
        "createdBy": null,
        "updatedBy": null,
        "fakeXAxis": "数据5",
        "指标1": null,
        "指标2": 65,
        "指标3": 82,
        "age": 22,
        "sex": "男",
        "averageScore": 75,
        "mentor": "张老师",
        "donation": 2700
      }
    }

  ],
  "first": true,
  "totalElements": 5,
  "empty": false
}
