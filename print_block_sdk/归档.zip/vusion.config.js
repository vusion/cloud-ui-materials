module.exports = {
    type: 'component',
    docs: {
        components: [
            { group: '组件', name: 'cw-print-view',path: "./components/cw-print-view/api.yaml"},,
            // Conponents Route List
        ],
    },
};
