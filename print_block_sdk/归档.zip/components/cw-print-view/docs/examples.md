### 基本用法

``` html
<cw-print-view :isShowPrint="true"></cw-print-view>
```
