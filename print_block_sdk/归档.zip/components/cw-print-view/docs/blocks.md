### 基本用法

``` html
<cw-print-view></cw-print-view>
```
