import CwPrintView from "./index.vue"

export default CwPrintView