module.exports = {
    type: 'component',
    docs: {
        components: [
            { group: '组件', name: 'cw-calendar-table',path: "./components/cw-calendar-table/api.yaml"},,
            // Conponents Route List
        ],
    },
};
