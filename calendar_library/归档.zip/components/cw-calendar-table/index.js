import CwCalendarTable from "./index.vue"

export default CwCalendarTable