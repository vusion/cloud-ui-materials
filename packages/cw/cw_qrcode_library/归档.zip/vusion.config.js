module.exports = {
    type: 'component',
    docs: {
        components: [
            { group: '组件', name: 'cw-qrcode-scan-view',path: "./components/cw-qrcode-scan-view/api.yaml"},,
            // Conponents Route List
        ],
    },
};
