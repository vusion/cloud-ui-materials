### 基本用法

``` html
<cw-qrcode-scan-view></cw-qrcode-scan-view>
```
