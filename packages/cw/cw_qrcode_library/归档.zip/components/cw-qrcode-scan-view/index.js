import CwQrcodeScanView from "./index.vue"

export default CwQrcodeScanView