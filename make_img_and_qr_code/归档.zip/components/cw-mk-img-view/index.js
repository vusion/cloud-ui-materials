import CwMkImgView from "./index.vue"

export default CwMkImgView