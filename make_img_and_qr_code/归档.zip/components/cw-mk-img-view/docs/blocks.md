### 基本用法

``` html
<cw-mk-img-view></cw-mk-img-view>
```
