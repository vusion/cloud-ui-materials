### 基本用法

``` html
<cw-mk-img-view><div>123<img src="http://ceph.lcap.hatest.163yun.com/lcap-test-static/user/defaulttenant/1687777814523_ima29.png"/> </div></cw-mk-img-view>
```


