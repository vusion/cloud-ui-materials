import CwBarcodeView from "./index.vue"

export default CwBarcodeView