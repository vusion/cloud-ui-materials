### 基本用法

``` html
<cw-barcode-view></cw-barcode-view>
```
