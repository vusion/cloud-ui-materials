import CwQrcodeView from "./index.vue"

export default CwQrcodeView