### 基本用法

``` html
<cw-qrcode-view value="fa"></cw-qrcode-view>
```
