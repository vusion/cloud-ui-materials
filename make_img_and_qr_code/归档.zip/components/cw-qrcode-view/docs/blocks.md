### 基本用法

``` html
<cw-qrcode-view></cw-qrcode-view>
```
