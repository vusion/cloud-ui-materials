module.exports = {
    type: 'component',
    docs: {
        components: [
            { group: '组件', name: 'cw-mk-img-view',path: "./components/cw-mk-img-view/api.yaml"},,
            { group: '组件', name: 'cw-qrcode-view',path: "./components/cw-qrcode-view/api.yaml"},,
            { group: '组件', name: 'cw-barcode-view',path: "./components/cw-barcode-view/api.yaml"},,
            // Conponents Route List
        ],
    },
};
